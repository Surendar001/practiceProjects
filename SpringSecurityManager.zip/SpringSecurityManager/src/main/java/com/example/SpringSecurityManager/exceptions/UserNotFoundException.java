package com.example.SpringSecurityManager.exceptions;

public class UserNotFoundException extends RuntimeException  {
	private static final long serialVersionUID = 1L;
}
